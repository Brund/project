export class User {

  userId: number;
  userName: string;
  type: String;
  bname:String;
  password: string;
  role: string;



}
